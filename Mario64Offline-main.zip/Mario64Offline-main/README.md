# Super Mario 64 Offline Build
A web port of Super Mario 64, BUT a offline verison.

# What's Different?

Super Mario 64 web was already a thing but this version it is a downloadable offline HTML to play without wifi. So for example if schools blocked the other domains of the game simply download the file and avoid schools detecting a blocked website.

# Slight Issue..

Make sure before the game loads to click on the page so the audio works.
