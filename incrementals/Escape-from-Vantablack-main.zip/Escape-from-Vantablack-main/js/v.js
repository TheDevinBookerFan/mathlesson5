var app;

function loadVue() {
	app = new Vue({
	    el: "#app",
	    data: {
			player,
			tmp,
			format,
			formatWhole,
			formatWhether,
			formatTime,
			tab,
			allTabs,
			tabUnlocks,
			buyUpg,
			UPG_DATA,
			checkFunc,
			annihilatePP,
			LUM_UPG_DATA,
			buyLumUpg,
			gameData,
			Decimal,
			truePhotonBtn,
			forceAppUpd,
        }
	})
}