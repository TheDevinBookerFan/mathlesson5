var app;

function loadVue() {
	app = new Vue({
	    el: "#app",
	    data: {
			player,
			tmp,
			format,
			formatWhole,
			formatTime,
			tab,
			allTabs,
			tabUnlocks,
			getSpiritBoostReq,
			buySpiritBoost,
			getSpiritBoostDesc,
			spiritBoosts,
			getSpiritBoostEffDesc,
			raptureUpgs,
			buyRaptureUpg,
			getNextFeatureDisplay,
			worlds,
			auto_data,
			spells,
			activateSpell,
        }
	})
}