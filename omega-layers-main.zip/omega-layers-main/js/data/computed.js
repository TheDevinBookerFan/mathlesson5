var computed = {
    isMeta: function()
    {
        return game.metaLayer.active;
    }
};