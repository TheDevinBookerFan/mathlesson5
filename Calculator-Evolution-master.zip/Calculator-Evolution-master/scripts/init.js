initAchievements();
setEffects();
